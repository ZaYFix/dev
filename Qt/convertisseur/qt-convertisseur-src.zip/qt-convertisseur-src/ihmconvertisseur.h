#ifndef IHMCONVERTISSEUR_H
#define IHMCONVERTISSEUR_H

#include <QtWidgets>

#define FARENHEIT   0
#define CELCIUS     1

class IHMConvertisseur : public QWidget
{
    Q_OBJECT

private:
    QLineEdit   *valeur;
    QLabel      *resultat;
    QLabel      *unite;
    QComboBox   *choixConversion;
    QPushButton *boutonConvertir;
    QPushButton *boutonQuitter;

    void afficherUnite();

public:
    IHMConvertisseur(QWidget *parent = 0);
    ~IHMConvertisseur();

signals:
    void actualiser();

private slots:
    void convertir();
    void permuter(int index);
};

#endif // IHMCONVERTISSEUR_H
