#include "ihmconvertisseur.h"

IHMConvertisseur::IHMConvertisseur(QWidget *parent)
    : QWidget(parent)
{    
    /* instancier les wigets */
    valeur = new QLineEdit(this);
    resultat = new QLabel(this);
    unite = new QLabel(this);
    choixConversion = new QComboBox(this);
    boutonConvertir = new QPushButton(QString::fromUtf8("Convertir"), this);
    boutonQuitter = new QPushButton(QString::fromUtf8("Quitter"), this);

    /* initialiser les wigets */
    valeur->clear();
    resultat->setText("--.--");
    unite->setText(QString::fromUtf8(" °F"));
    choixConversion->addItem("Celcius -> Farenheit");
    choixConversion->addItem("Farenheit -> Celcius");
    choixConversion->setCurrentIndex(FARENHEIT);

    /* positionner les wigets */
    QHBoxLayout *hLayout1 = new QHBoxLayout;
    QHBoxLayout *hLayout2 = new QHBoxLayout;
    QVBoxLayout *mainLayout = new QVBoxLayout;
    hLayout1->addWidget(valeur);
    hLayout1->addWidget(choixConversion);
    hLayout1->addWidget(resultat);
    hLayout1->addWidget(unite);
    hLayout2->addWidget(boutonConvertir);
    hLayout2->addWidget(boutonQuitter);
    mainLayout->addLayout(hLayout1);
    mainLayout->addLayout(hLayout2);
    setLayout(mainLayout);

    /* connecter les signaux aux slots */
    connect(choixConversion, SIGNAL(currentIndexChanged(int)), this, SLOT(permuter(int)));
    connect(this, SIGNAL(actualiser()), this, SLOT(convertir()));
    connect(boutonConvertir, SIGNAL(clicked()), this, SLOT(convertir()));
    connect(boutonQuitter, SIGNAL(clicked()), qApp, SLOT(quit()));

    /* initialiser la fenêtre : dimensions, titre */
    setGeometry(QStyle::alignedRect(Qt::LeftToRight, Qt::AlignCenter, minimumSizeHint(), qApp->desktop()->availableGeometry()));
    setWindowTitle("Conversion d'unités marines");
}

IHMConvertisseur::~IHMConvertisseur()
{

}

void IHMConvertisseur::convertir()
{
    if (valeur->text().isEmpty())
    {
        resultat->setText(QString::fromUtf8("--.--"));
        afficherUnite();
        return;
    }
    switch (choixConversion->currentIndex())
    {
        case FARENHEIT:
            resultat->setText(QString::fromUtf8("%1").arg(9 * valeur->text().toDouble() / 5 + 32, 0, 'f', 2));
            break;
        case CELCIUS:
            resultat->setText(QString::fromUtf8("%1").arg(5 * (valeur->text().toDouble() - 32 )  / 9, 0, 'f', 2));
            break;
    }
}

void IHMConvertisseur::permuter(int index)
{
    Q_UNUSED(index)
    if(resultat->text() != "--.--")
    {
        valeur->setText(resultat->text());
        emit actualiser();
    }
    afficherUnite();
}

void IHMConvertisseur::afficherUnite()
{
    switch (choixConversion->currentIndex())
    {
        case FARENHEIT:
            unite->setText(QString::fromUtf8(" °F"));
            break;
        case CELCIUS:
            unite->setText(QString::fromUtf8(" °C"));
            break;
    }
}
