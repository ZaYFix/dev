var indexSectionsWithContent =
{
  0: "acdehilmnoprstuv~",
  1: "cils",
  2: "u",
  3: "cilms",
  4: "acdeilmnorst~",
  5: "acehilpstuv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Espaces de nommage",
  3: "Fichiers",
  4: "Fonctions",
  5: "Variables"
};

