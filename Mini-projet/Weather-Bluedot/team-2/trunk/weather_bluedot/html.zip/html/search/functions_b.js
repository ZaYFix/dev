var searchData=
[
  ['trameprete',['tramePrete',['../class_communication.html#a3b51e6cec94cbc95f55c2de01802cb09',1,'Communication']]]
];
