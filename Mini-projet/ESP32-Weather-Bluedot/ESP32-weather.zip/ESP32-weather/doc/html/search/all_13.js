var searchData=
[
  ['°c',['°C',['../_r_e_a_d_m_e_8dox.html#a7df9d55759e01848b2c54068d3ccbed6',1,'README.dox']]]
];
