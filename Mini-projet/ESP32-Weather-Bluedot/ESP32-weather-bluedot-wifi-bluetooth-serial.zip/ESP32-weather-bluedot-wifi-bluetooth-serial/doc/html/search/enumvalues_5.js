var searchData=
[
  ['vert',['Vert',['../ledbicolore_8h.html#aa304d0ca681f782b1d7735da33037dd7aa1d538486b3faf4668a79c2588f2eb5c',1,'ledbicolore.h']]]
];
