var searchData=
[
  ['nbtentatives',['nbTentatives',['../class_mon_serveur.html#ac73b1bdbd28723c8f8b4e232e1c3d732',1,'MonServeur']]],
  ['numeroclient',['numeroClient',['../struct_requete.html#a34d99957f8cfc9efb5e6d55cf9c15e44',1,'Requete']]]
];
